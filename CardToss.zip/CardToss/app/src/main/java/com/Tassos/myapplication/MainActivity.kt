package com.Tassos.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random
import android.content.Intent

class MainActivity : AppCompatActivity() {
    private var redGem = 0
    private var redCurve = 0

    private lateinit var cardImage: ImageView
    private lateinit var redGemCount: TextView
    private lateinit var redCurveCount: TextView
    private lateinit var tossButton: Button
    private lateinit var signUpButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // connect UI components
        cardImage = findViewById(R.id.cardImage)
        redGemCount = findViewById(R.id.redGemCount)
        redCurveCount = findViewById(R.id.redCurveCount)
        tossButton = findViewById(R.id.tossButton)
        signUpButton = findViewById(R.id.signUpButton)

        // Initialize text using string resources
        updateCounterText()

        // Toss button logic
        tossButton.setOnClickListener {
            tossCard()
        }

        // Sign up button logic
        signUpButton.setOnClickListener {
            val intent = Intent(this, SignIn::class.java)
            startActivity(intent)
        }
    }

    private fun tossCard() {
        val result = Random.nextBoolean() // true = red gem and false = red curve

        if(result) {
            redGem++
            cardImage.setImageResource(R.drawable.red_gem)
        } else {
            redCurve++
            cardImage.setImageResource(R.drawable.red_curve)
        }

        // update the counters
        updateCounterText()
    }

    private fun updateCounterText() {
        redGemCount.text = getString(R.string.red_gem_count, redGem)
        redCurveCount.text = getString(R.string.red_curve_count, redCurve)
    }
}
